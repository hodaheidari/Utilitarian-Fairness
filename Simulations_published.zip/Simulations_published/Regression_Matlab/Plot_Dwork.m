function Plot_Dwork(dataset_name, Alpha, Tau)
    load(['Output/',dataset_name,'.mat']);
    
    Dw = zeros(length(Alpha),length(Tau));
    n_folds = max(F);
    for fold=1:n_folds
        Y_test = Y(F==fold);
  
        alphaIndex = 0;
        for alpha=Alpha
            alphaIndex= alphaIndex+1;

            for tauIndex=1:length(Tau)
                Y_hat = Y_predicted(F==fold,alphaIndex,tauIndex);
                [avg_viol, ~, ~] = Measure_Dwork(Y_test, Y_hat, 0);     
                Dw(alphaIndex, tauIndex) = Dw(alphaIndex, tauIndex) + avg_viol;
            end
        end
    end
    Dw = Dw./n_folds;
    
    f1=figure(1);
    set(0,'DefaultAxesFontSize', 22)
    alphaIndex = 0;
    for alpha=Alpha
        alphaIndex = alphaIndex+1;
        plot(Tau,Dw(alphaIndex,:),'Color', [0, 0 , alpha],'LineWidth',3)
        hold on
    end
    xlim([min(Tau),max(Tau)]);
    xlabel('\tau');
    ylabel('average violation');
    title('Crime and Communities')
    legend(['\alpha=',num2str(Alpha(1))],['\alpha=',num2str(Alpha(2))],...
    ['\alpha=',num2str(Alpha(3))],['\alpha=',num2str(Alpha(4))],...
    ['\alpha=',num2str(Alpha(5))],'Location','southeast')  
    saveas(f1,['Plots/',dataset_name,'_Dwork'],'png');
    clf(f1);
    close(f1);

end

