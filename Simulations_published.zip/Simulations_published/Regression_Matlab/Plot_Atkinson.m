function Plot_Atkinson(dataset_name, Alpha, Tau)
    load(['Output/',dataset_name,'.mat']);
    
    AT = zeros(length(Alpha),length(Tau));
    n_folds = max(F);
    for fold=1:n_folds
        Y_test = Y(F==fold);
        
        alphaIndex = 0;
        for alpha=Alpha
            alphaIndex= alphaIndex+1;
            for tauIndex=1:length(Tau)
                Y_hat = Y_predicted(F==fold,alphaIndex,tauIndex);
                AT(alphaIndex,tauIndex) = AT(alphaIndex,tauIndex) + ...
                    Measure_Atkinson(Y_test, Y_hat, alpha);      
            end
        end
    end
    AT = AT./n_folds;
    
    f1=figure(1);
    set(0,'DefaultAxesFontSize', 22)
    alphaIndex = 0;
    for alpha=Alpha
        alphaIndex = alphaIndex+1;
        plot(Tau,AT(alphaIndex,:),'Color', [alpha, 0 , 0],'LineWidth',3)
        hold on
    end
    xlim([min(Tau),max(Tau)]);
    xlabel('\tau');
    ylabel('Atkinson Index');
    title('Crime and Communities')
    legend(['\alpha=',num2str(Alpha(1))],['\alpha=',num2str(Alpha(2))],...
        ['\alpha=',num2str(Alpha(3))],['\alpha=',num2str(Alpha(4))],...
        ['\alpha=',num2str(Alpha(5))],'Location','northeast')           
    saveas(f1,['Plots/',dataset_name,'_AT'],'png');
    clf(f1);
    close(f1);

end