function md = Measure_mean_difference(Y_predicted, G)
   % G specifies the group membership of each individual
   n1 = sum(G==1);
   n2 = sum(G==0);
   md = 0;
   if (n1>0 && n2>0) 
       md = abs(sum(Y_predicted.*(G==1))/n1 - sum(Y_predicted.*(G==0))/n2);
   end
end