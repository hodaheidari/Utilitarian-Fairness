% Preprocessing the Crime and Communities data

load('Crime_normalized')
% Crime_original.mat does not include non-predictive attributes: communityname,
% state, countyCode, communityCode, and fold

% Removed target variables other than total number of nonviolent crimes per
% capita
X = Crimenormalized(:,1:122);
Y = Crimenormalized(:, 123);

load('Crime_original')
G = Crime(:,3)+Crime(:,5)+Crime(:,6)>50;
instance_ind = find(isnan(Crime(:, 141))==0);
G = G(instance_ind);

% Remove the features with NaN values
feature_ind = find(sum(isnan(X),1)==0);
X = X(:,feature_ind);
% X(isnan(X)) = 0;

n = length(Y); % Number of training instances

% Homogenization
X = [X, ones(n,1)];


% Note that in the Crime data larger Y is less desirable
Y = 1.-Y;

% 10-fold cross validation
k=10;
p = randperm(n);
X = X(p, :);
Y = Y(p ,:);
G = G(p ,:);
F = ceil((1:n)./(n/k));

save('CrimeNormalizedViol.mat','X', 'Y', 'G', 'F');