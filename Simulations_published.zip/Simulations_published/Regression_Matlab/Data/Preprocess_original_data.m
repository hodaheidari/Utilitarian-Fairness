% Preprocessing the Crime and Communities data

load('Crime_original')
% Crime_original.mat does not include non-predictive attributes: communityname,
% state, countyCode, communityCode, and fold

% Removed target variables other than total number of nonviolent crimes per
% capita
X = Crime(:,1:124);
Y = Crime(:, 141);
G = Crime(:,3)+Crime(:,5)+Crime(:,6)>50;

% Remove the instances for which Y value is NaN
instance_ind = find(isnan(Y)==0);
X = X(instance_ind,:);
Y = Y(instance_ind,:);
G = G(instance_ind);

% Remove the features with NaN values
feature_ind = find(sum(isnan(X),1)==0);
X = X(:,feature_ind);
% X(isnan(X)) = 0;

n = length(Y); % Number of training instances
k = size(X,2); % Number of features

% Renormalization
mu = zeros(1,k);
sigma2 = zeros(1,k);

for i=1:k
    mu(i) = mean(X(:,i));
    sigma2(i) = mean((X(:,i) - mu(i)).^2);
    X(:,i) = (X(:,i) - mu(i))./sqrt(sigma2(i));
end

% Homogenization
X = [X, ones(n,1)];

% Rescale the target variable so its range is comparable with
% classification, i.e. it's [0,1]
Y = Y./max(Y);

% Note that in the Crime data larger Y is less desirable
Y = 1.-Y;

% 10-fold cross validation
n_folds=5;
p = randperm(n);
X = X(p, :);
Y = Y(p ,:);
G = G(p ,:);
F = ceil((1:n)./(n/n_folds));

save(['CrimeViol',num2str(n_folds),'.mat'],'X', 'Y', 'G', 'F');