function at = Measure_Atkinson(Y, Y_predicted, alpha)
   B = Benefit(Y,Y_predicted);
   mu = mean(B);
   if (alpha>0 && sum(B<0)==0)
       at = 1-(1/mu)*(mean(B.^alpha)^(1/alpha));
   elseif (alpha==0)
       n = length(Y);
       at = 1-(1/mu)*(prod(B)^(1/n));
   else
       'Warning!!!!'
       at = 0;
   end
   
end