function [c,ceq] = ATcon(W, X, Y, alpha, eta)
c = - mean(max(0,(X * W - Y + 1)).^alpha)^(1/alpha) + mean((X * W - Y + 1))*(1-eta);
ceq = [ ];