function Plot_social_welfare(dataset_name, Alpha, Tau)
    load(['Output/',dataset_name,'.mat']);
    
    SW = zeros(length(Alpha),length(Tau));
    n_folds = max(F);
    for fold=1:n_folds
        Y_test = Y(F==fold);
        
        alphaIndex = 0;
        for alpha=Alpha
            alphaIndex= alphaIndex+1;
            for tauIndex=1:length(Tau)
                Y_hat = Y_predicted(F==fold,alphaIndex,tauIndex);
                SW(alphaIndex,tauIndex) = SW(alphaIndex,tauIndex) + ...
                    Measure_social_welfare(Y_test, Y_hat, alpha);      
            end
        end
    end
    SW = SW./n_folds;
    
    f1=figure(1);
    set(0,'DefaultAxesFontSize', 22)
    alphaIndex = 0;
    for alpha=Alpha
        alphaIndex = alphaIndex+1;
        plot(Tau,SW(alphaIndex,:),'Color', [0, alpha , alpha],'LineWidth',3)
        hold on
    end
    xlim([min(Tau),max(Tau)]);
    xlabel('\tau');
    ylabel('Social Welfare');
    title('Crime and Communities')
    legend(['\alpha=',num2str(Alpha(1))],['\alpha=',num2str(Alpha(2))],...
        ['\alpha=',num2str(Alpha(3))],['\alpha=',num2str(Alpha(4))],...
        ['\alpha=',num2str(Alpha(5))],'Location','northeast')           
    saveas(f1,['Plots/',dataset_name,'_SW'],'png');
    clf(f1);
    close(f1);

end