function Plot_all(dataset_name)
    load(['Output/',dataset_name,'.mat']);
    Plot_Atkinson(dataset_name,Alpha,Tau)
    Plot_Dwork(dataset_name,Alpha,Tau)
    Plot_mean_difference(dataset_name,Alpha,Tau)
    Plot_positive_residual_difference(dataset_name,Alpha,Tau)
    Plot_negative_residual_difference(dataset_name,Alpha,Tau)
    Plot_loss(dataset_name,Alpha,Tau)
    Plot_social_welfare(dataset_name,Alpha,Tau)
    
    Plot_weights(dataset_name,Alpha,Tau)
    
    Bar_ranking(dataset_name,Alpha)
    
end