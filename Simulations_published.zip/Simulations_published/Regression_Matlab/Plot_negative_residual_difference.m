function Plot_negative_residual_difference(dataset_name, Alpha, Tau)
    load(['Output/',dataset_name,'.mat']);
    
    NRD = zeros (length(Alpha),length(Tau));
    n_folds = max(F);
    for fold=1:n_folds
        G_test = G(F==fold);
        Y_test = Y(F==fold);
        
        alphaIndex = 0;
        for alpha=Alpha
            alphaIndex= alphaIndex+1;
           for tauIndex=1:length(Tau)
                Y_hat = Y_predicted(F==fold,alphaIndex,tauIndex);       
                nrd = Measure_negative_residual_difference(Y_test, Y_hat, G_test);
                NRD(alphaIndex, tauIndex) = NRD(alphaIndex, tauIndex) + nrd;
            end      
        end
    end
    NRD = NRD./n_folds;
    
    f1=figure(1);
    set(0,'DefaultAxesFontSize', 22)
    alphaIndex = 0;
    for alpha=Alpha
        alphaIndex = alphaIndex+1;
        plot(Tau, NRD(alphaIndex,:),'Color', [alpha, alpha , 0],'LineWidth',3)
        hold on
    end    
    xlim([min(Tau),max(Tau)]);
    xlabel('\tau');
    ylabel('negative residual difference');
    title('Crime and Communities')
    legend(['\alpha=',num2str(Alpha(1))],['\alpha=',num2str(Alpha(2))],...
    ['\alpha=',num2str(Alpha(3))],['\alpha=',num2str(Alpha(4))],...
    ['\alpha=',num2str(Alpha(5))],'Location','northeast')  
    saveas(f1,['Plots/',dataset_name,'_NRD'],'png');
    clf(f1);
    close(f1);

end