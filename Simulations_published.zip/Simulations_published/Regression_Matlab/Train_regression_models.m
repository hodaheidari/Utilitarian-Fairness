function Train_regression_models(dataset_name)
    load(['Data/',dataset_name,'.mat']);
    
    n = length(Y);
    k = size(X,2); % Number of features  

    Y_lasso = zeros(n,1);
    Y_elastic = zeros(n,1);
    Y_ridge = zeros(n,1);
    Y_NN = zeros(n,1);
    Y_SVM = zeros(n,1);
    Y_tree = zeros(n,1);
    Y_ensemble = zeros(n,1);
    Y_GPR = zeros(n,1);
    
    n_folds = max(F);
    
    for fold=1:n_folds
        fold 
        X_test = X(F==fold,:);
        Y_test = Y(F==fold,:);
        X_train = X(F~=fold,:);
        Y_train = Y(F~=fold,:);
        
        % Train different regression models on the data

        % Lasso with cross validation
        [~,FitInfo] = lasso(X_train,Y_train,'CV',5); 
        lambda = FitInfo.Lambda1SE;
        [W,FitInfo] = lasso(X_train,Y_train,'Lambda',lambda); 
        Y_lasso(F==fold) = X_test*W + FitInfo.Intercept;

        % Elastic nets with cross validation
        [~,FitInfo] = lasso(X_train,Y_train,'CV',5,'Alpha',0.5);
        lambda = FitInfo.Lambda1SE;
        [W,FitInfo] = lasso(X_train,Y_train,'Lambda',lambda,'Alpha',0.5); 
        Y_elastic(F==fold) = X_test*W + FitInfo.Intercept;

%         % Ridge with cross validation
%         [~,FitInfo] = lasso(X_train,Y_train,'CV',5,'Alpha',0.01);
%         lambda = FitInfo.Lambda1SE;
%         [W,FitInfo] = lasso(X_train,Y_train,'Lambda',lambda,'Alpha',0.01); 
%         Y_ridge(F==fold) = X_test*W + FitInfo.Intercept;


%         % SVM Regression    
%         mdl = fitrsvm(X_train,Y_train,'KernelFunction','gaussian');
%         Y_SVM(F==fold) = predict(mdl,X_test);

        % Neural Network with hold-out validation
        hiddenLayerSize = 1;
        net = fitnet(hiddenLayerSize);    
        net.divideParam.trainRatio = 85/100;
        net.divideParam.valRatio = 15/100;
        net.divideParam.testRatio = 0/100;
        [net, ~] = train(net, X_train', Y_train');
        Y_NN(F==fold) = net(X_test')';

%         % Regression tree
%         tree = fitrtree(X_train,Y_train);
%         Y_tree(F==fold) = predict(tree,X_test);
        
        % Ensemble tree
        ensemble = fitrensemble(X_train,Y_train);
        Y_ensemble(F==fold) = predict(ensemble,X_test);
        
        % Gaussian process regression
        mdl = fitrgp(X_train,Y_train);
        Y_GPR(F==fold) = predict(mdl,X_test);

    end
    save(['Output/',dataset_name,'_regressors.mat'],'Y', ...
        'Y_lasso', 'Y_elastic', 'Y_ridge', 'Y_GPR', ...
        'Y_tree', 'Y_ensemble','Y_SVM', 'Y_NN', 'F');
    
end