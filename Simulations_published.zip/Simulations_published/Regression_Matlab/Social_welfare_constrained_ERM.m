function Social_welfare_constrained_ERM(dataset_name, Alpha, Tau)
    % Load X, Y, G, F
    load(['Data/',dataset_name]);
    
    n = length(Y);
    k = size(X,2); % Number of features  

    % loss = zeros(length(Alpha),length(Tau)); 
    W_all = zeros(k,length(Alpha),length(Tau)); 
    Y_predicted = zeros(n,length(Alpha),length(Tau));
    
    n_folds = max(F);
    for fold=1:n_folds
        fold
        X_test = X(F==fold,:);
        Y_test = Y(F==fold,:);
        X_train = X(F~=fold,:);
        Y_train = Y(F~=fold,:);
        
        n_train = length(Y_train); % Number of train instances
        n_test = length(Y_test); % Number of test instances

        alphaIndex = 0;
        for alpha=Alpha
            alphaIndex = alphaIndex+1

            tauIndex = 0;
            for tau=Tau
                tauIndex = tauIndex+1
                if (alpha>0)
                    cvx_begin quiet
                    cvx_precision high         
                    variable W(k)
                        minimize( norm( X_train * W - Y_train, 2 ) )
                         subject to
                         ones(1,n_train)*((X_train * W - Y_train + 1).^alpha) >= n_train*tau
                    cvx_end
                else
                    cvx_begin quiet
                    cvx_precision high         
                    variable W(k)
                        minimize( norm( X_train * W - Y_train, 2 ) )
                         subject to
                         X_train * W - Y_train + 1 >= tau*ones(n_train,1)
                    cvx_end
                end

                Y_hat = X_test * W;

                % loss(alphaIndex,tauIndex) = mean((Y_test - Y_hat).^2);
                W_all(:, alphaIndex, tauIndex) = W_all(:, alphaIndex, tauIndex) + W;
                Y_predicted(F==fold, alphaIndex,tauIndex) = Y_hat;
            end
        end
    end
    W_all = W_all ./n_folds;
    save(['Output/',dataset_name,'.mat'],'Y', 'Y_predicted', 'G', 'F', 'Alpha','Tau', 'W_all');
end

