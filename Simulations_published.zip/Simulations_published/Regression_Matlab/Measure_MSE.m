function mse = Measure_MSE(Y, Y_predicted)
   mse = mean((Y-Y_predicted).^2);
end