function prd = Measure_positive_residual_difference(Y, Y_predicted, G)
   % G specifies the group membership of each individual
   % prd = difference in positive residuals
   prd = 0;
   
   n1 = sum(G==1 & Y_predicted>=Y);
   n2 = sum(G==0 & Y_predicted>=Y);   
%    if (n1>0 && n2>0) 
%        prd = abs(sum((Y_predicted-Y).*(G==1 & Y_predicted>=Y))/n1 - sum((Y_predicted-Y).*(G==0 & Y_predicted>=Y))/n2);
%    end
   
   pr1=0;
   pr2=0;
   if (n1>0) 
       pr1 = sum((Y-Y_predicted).*(G==1 & Y_predicted>=Y))/n1;
   end
   
   if (n2>0)
       pr2 = sum((Y-Y_predicted).*(G==0 & Y_predicted>=Y))/n2;
   end
   prd = abs(pr1 - pr2);
end