function loss=Plot_loss(dataset_name, Alpha, Tau)
    load(['Output/',dataset_name,'.mat']);
    
    loss = zeros(length(Alpha),length(Tau));
    n_folds = max(F);
    for fold=1:n_folds
        Y_test = Y(F==fold);
        
        alphaIndex = 0;
        for alpha=Alpha
            alphaIndex= alphaIndex+1;
            tauIndex = 0;

            for tau=Tau
                tauIndex= tauIndex+1;
                loss(alphaIndex, tauIndex) = loss(alphaIndex, tauIndex) + ...
                    Measure_MSE(Y_test, Y_predicted(F==fold,alphaIndex,tauIndex));
            end
        end
    end
    loss = loss./n_folds;
    
    f1=figure(1);
    set(0,'DefaultAxesFontSize', 22)
    alphaIndex = 0;
    for alpha=Alpha
        alphaIndex = alphaIndex+1;
        plot(Tau,min(1,loss(alphaIndex,:)),'Color', [alpha, alpha , alpha],'LineWidth',3)
        hold on
    end        
    xlim([min(Tau),max(Tau)]);
    xlabel('\tau');
    ylabel('MSE'); 
    title('Crime and Communities');
    legend(['\alpha=',num2str(Alpha(1))],['\alpha=',num2str(Alpha(2))],...
    ['\alpha=',num2str(Alpha(3))],['\alpha=',num2str(Alpha(4))],...
    ['\alpha=',num2str(Alpha(5))],'Location','northeast')      
    saveas(f1,['Plots/',dataset_name,'_loss'],'png');
    clf(f1);
end