function Bar_ranking(dataset_name, Alpha)
    load(['Output/',dataset_name,'_regressors.mat']);
    %c = {'GPR','Ridge', 'LASSO', 'Elastic net','NN','SVM', 'Tree', 'Ensemble'};
    c = {'GPR','Trees','LASSO','Elastic','NN'};
    n_algs = length(c);
    n_folds = max(F);
    
    % Stuff for computing confidence intervals
    df = n_folds-1;
    level = (1-0.95)/2;
    coeff = -tinv(level,df);
    
    f1=figure(1);
    set(0,'DefaultAxesFontSize', 22)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    MSE = zeros(n_folds,n_algs);
    for fold=1:n_folds
        Y_test = Y(F==fold);
        MSE(fold,1) = Measure_MSE(Y_test, Y_GPR(F==fold));
        %MSE(fold,2) = Measure_MSE(Y_test, Y_ridge(F==fold));
        MSE(fold,3) = Measure_MSE(Y_test, Y_lasso(F==fold));
        MSE(fold,4) = Measure_MSE(Y_test, Y_elastic(F==fold));
        MSE(fold,5) = Measure_MSE(Y_test, Y_NN(F==fold));
        %MSE(fold,6) = Measure_MSE(Y_test, Y_SVM(F==fold));
        %MSE(fold,7) = Measure_MSE(Y_test, Y_tree(F==fold));
        MSE(fold,2) = Measure_MSE(Y_test, Y_ensemble(F==fold));
    end
    MSE_mean = mean(MSE,1);
    MSE_err = zeros(1,n_algs);
    
    for i=1:n_algs     
        MSE_err(i) = std(MSE(:,i))/sqrt(n_folds) * coeff;
    end

    [~ , I] = sort(MSE_mean);
    bar(1:n_algs, MSE_mean(I),'w');
    hold on 
    errorbar(1:n_algs, MSE_mean(I), MSE_err(I),'.k');
    set(gca, 'XTickLabel', c(I), 'XTick',1:n_algs);

    title('Crime and Communities')
    ylabel('MSE') 
    saveas(f1,['Plots/',dataset_name,'_bar_MSE'],'png');
    clf(f1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    DwI = zeros(n_folds,n_algs);
    for fold=1:n_folds
        Y_test = Y(F==fold);
        DwI(fold,1) = Measure_Dwork(Y_test, Y_GPR(F==fold), 0);
        %DwI(fold,2) = Measure_Dwork(Y_test, Y_ridge(F==fold), 0);
        DwI(fold,3) = Measure_Dwork(Y_test, Y_lasso(F==fold), 0);
        DwI(fold,4) = Measure_Dwork(Y_test, Y_elastic(F==fold), 0);
        DwI(fold,5) = Measure_Dwork(Y_test, Y_NN(F==fold), 0);
        %DwI(fold,6) = Measure_Dwork(Y_test, Y_SVM(F==fold), 0);
        %DwI(fold,7) = Measure_Dwork(Y_test, Y_tree(F==fold), 0);
        DwI(fold,2) = Measure_Dwork(Y_test, Y_ensemble(F==fold), 0);
    end
    DwI_mean = mean(DwI,1);
    DwI_err = zeros(1,n_algs);
    
    for i=1:n_algs     
        DwI_err(i) = std(DwI(:,i))/sqrt(n_folds) * coeff;
    end

    [~ , I] = sort(DwI_mean);
    bar(1:n_algs, DwI_mean(I),'b');
    hold on 
    errorbar(1:n_algs, DwI_mean(I), DwI_err(I),'.k');
    set(gca, 'XTickLabel', c(I), 'XTick',1:n_algs);

    title('Crime and Communities')
    ylabel('Dwork') 
    saveas(f1,['Plots/',dataset_name,'_bar_Dw'],'png');
    clf(f1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for alpha=Alpha
        SW = zeros(n_folds,n_algs);
        for fold=1:n_folds
            Y_test = Y(F==fold);
            SW(fold,1) = Measure_social_welfare(Y_test, Y_GPR(F==fold), alpha);
            %SW(fold,2) = Measure_social_welfare(Y_test, Y_ridge(F==fold), alpha);
            SW(fold,3) = Measure_social_welfare(Y_test, Y_lasso(F==fold), alpha);
            SW(fold,4) = Measure_social_welfare(Y_test, Y_elastic(F==fold), alpha);
            SW(fold,5) = Measure_social_welfare(Y_test, Y_NN(F==fold), alpha);
            %SW(fold,6) = Measure_social_welfare(Y_test, Y_SVM(F==fold), alpha);
            %SW(fold,7) = Measure_social_welfare(Y_test, Y_tree(F==fold), alpha);
            SW(fold,2) = Measure_social_welfare(Y_test, Y_ensemble(F==fold), alpha);
        end
        SW_mean = mean(SW,1);
        SW_err = zeros(1,n_algs);

        for i=1:n_algs     
            SW_err(i) = std(SW(:,i))/sqrt(n_folds) * coeff;
        end

        [~ , I] = sort(SW_mean,'descend');
        bar(1:n_algs, SW_mean(I),'c');
        hold on 
        errorbar(1:n_algs, SW_mean(I), SW_err(I),'.k');
        set(gca, 'XTickLabel', c(I), 'XTick',1:n_algs);
        
        ylim manual
        ylim([min(SW_mean - SW_err) max(SW_mean + SW_err)])

        title('Crime and Communities')
        ylabel(['Social Welfare (\alpha=',num2str(alpha),')']) 
        saveas(f1,['Plots/',dataset_name,'_bar_SW_alpha',num2str(alpha*100)],'png');
        clf(f1);
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for alpha=Alpha
        AT = zeros(n_folds,n_algs);
        for fold=1:n_folds
            Y_test = Y(F==fold);
            AT(fold,1) = Measure_Atkinson(Y_test, Y_GPR(F==fold), alpha);
            %AT(fold,2) = Measure_Atkinson(Y_test, Y_ridge(F==fold), alpha);
            AT(fold,3) = Measure_Atkinson(Y_test, Y_lasso(F==fold), alpha);
            AT(fold,4) = Measure_Atkinson(Y_test, Y_elastic(F==fold), alpha);
            AT(fold,5) = Measure_Atkinson(Y_test, Y_NN(F==fold), alpha);
            %AT(fold,6) = Measure_Atkinson(Y_test, Y_SVM(F==fold), alpha);
            %AT(fold,7) = Measure_Atkinson(Y_test, Y_tree(F==fold), alpha);
            AT(fold,2) = Measure_Atkinson(Y_test, Y_ensemble(F==fold), alpha);
        end
        AT_mean = mean(AT,1);
        AT_err = zeros(1,n_algs);
        
        for i=1:n_algs     
            AT_err(i) = std(AT(:,i))/sqrt(n_folds) * coeff;
        end

        [~ , I] = sort(AT_mean);
        bar(1:n_algs, AT_mean(I),'r');
        hold on 
        errorbar(1:n_algs, AT_mean(I), AT_err(I),'.k');
        set(gca, 'XTickLabel', c(I), 'XTick',1:n_algs);

        title('Crime and Communities')
        ylabel(['Atkinson Index (\alpha=',num2str(alpha),')']) 
        saveas(f1,['Plots/',dataset_name,'_bar_AT_alpha',num2str(alpha*100)],'png');
        clf(f1);
    end

end