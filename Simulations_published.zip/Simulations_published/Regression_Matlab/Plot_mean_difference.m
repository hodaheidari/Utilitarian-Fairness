function Plot_mean_difference(dataset_name, Alpha, Tau)
    load(['Output/',dataset_name,'.mat']);
    
    MD = zeros (length(Alpha),length(Tau));
    n_folds = max(F);
    for fold=1:n_folds
        G_test = G(F==fold);
        alphaIndex = 0;
        for alpha=Alpha
            alphaIndex= alphaIndex+1;
            for tauIndex=1:length(Tau)
                Y_hat = Y_predicted(F==fold,alphaIndex,tauIndex);      
                MD(alphaIndex,tauIndex) = MD(alphaIndex,tauIndex)+ ...
                    Measure_mean_difference(Y_hat, G_test);            
            end      
        end
    end
    MD = MD./n_folds;
    
    f1=figure(1);
    set(0,'DefaultAxesFontSize', 22)
    alphaIndex = 0;
    for alpha=Alpha
        alphaIndex = alphaIndex+1;
        plot(Tau,MD(alphaIndex,:),'Color', [alpha,0 , alpha],'LineWidth',3)
        hold on
    end    
    xlim([min(Tau),max(Tau)]);
    xlabel('\tau');
    ylabel('means difference');
    title('Crime and Communities')
    legend(['\alpha=',num2str(Alpha(1))],['\alpha=',num2str(Alpha(2))],...
    ['\alpha=',num2str(Alpha(3))],['\alpha=',num2str(Alpha(4))],...
    ['\alpha=',num2str(Alpha(5))],'Location','southeast')  
    saveas(f1,['Plots/',dataset_name,'_MD'],'png');
    clf(f1);
    close(f1);

end
