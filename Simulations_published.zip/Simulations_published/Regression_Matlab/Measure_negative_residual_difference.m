function nrd = Measure_negative_residual_difference(Y, Y_predicted, G)
   % G specifies the group membership of each individual
   % nrd = difference in negative residuals
   nrd = 0;
   
   n1 = sum(G==1 & Y_predicted<Y);
   n2 = sum(G==0 & Y_predicted<Y);
   nr1=0;
   nr2=0;
   if (n1>0) 
       nr1 = sum((Y-Y_predicted).*(G==1 & Y_predicted<Y))/n1;
   end
   
   if (n2>0)
       nr2 = sum((Y-Y_predicted).*(G==0 & Y_predicted<Y))/n2;
   end
   nrd = abs(nr1 - nr2);
end