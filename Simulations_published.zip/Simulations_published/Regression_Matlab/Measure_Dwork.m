function [avg_viol, num_viol, num_viol_delta] = Measure_Dwork(Y, Y_predicted , delta)
   avg_viol = 0;
   num_viol = 0;
   num_viol_delta = 0;
   n = length(Y_predicted); % Number of training instances
   for i = 1:n
       for j = i+1:n
           viol = max(0, abs(Y_predicted(i) - Y_predicted(j)) - abs(Y(i)-Y(j)));
           avg_viol = avg_viol + viol;
           if ( viol > 0)
               num_viol = num_viol+1;
           end
           if ( viol > delta)
               num_viol_delta = num_viol_delta+1;
           end
       end
   end
   avg_viol = 2*avg_viol/(n*(n-1));
end