function sw = Measure_social_welfare(Y, Y_predicted, alpha)
   B = Benefit(Y,Y_predicted);
   sw = mean(B.^alpha);
end