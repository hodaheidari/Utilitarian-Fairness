function Plot_weights(dataset_name, Alpha, Tau)
    load(['Output/',dataset_name,'.mat']);

    t = length(Tau);
    a = length(Alpha);
    k = length(W_all); %number of features
    
    col = {'r', 'g', 'b', 'm', 'y', 'k', 'c'};
    
    alphaIndex = 0;
    for alpha= Alpha
        alphaIndex = alphaIndex + 1;
        W = zeros(k,t);
        range = zeros(k,1);
        for i=1:k
            W(i,:) = reshape(W_all(i,alphaIndex, :), t,1);
            range(i) = max(W(i,:)) - min(W(i,:));
        end
        
        features = find(range >= 0.1*range(k));
        
        f1=figure(1);
        set(0,'DefaultAxesFontSize', 22)
        
        fIndex = 0;
        for f=features'
            fIndex = fIndex+1;
            plot(Tau, W(f,:),'Color', col{fIndex},'LineWidth',3)
            hold on
        end
        xlim([min(Tau),max(Tau)]);
        xlabel('\tau');
        ylabel('weights');
        title(['Crime and Communities (\alpha=',num2str(alpha),')'])
        legend(num2str(features),'Location','northeast')           
        saveas(f1,['Plots/',dataset_name,'_W_alpha',num2str(alpha*100)],'png');
        clf(f1);
        close(f1);
    end
end